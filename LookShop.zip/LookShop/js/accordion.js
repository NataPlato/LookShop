"use strict";
document.addEventListener("DOMContentLoaded", () => {
  const accordionBtn = document.querySelectorAll(".categories__block_title");
  const accordionList = document.querySelectorAll(".categories__block_links");

  accordionBtn.forEach((e, i) => {
    e.addEventListener("click", () => {
      e.classList.toggle("categories__block_title-active");
      accordionList[i].classList.contains("categories__block_links-active")
        ? accordionList[i].classList.remove("categories__block_links-active")
        : accordionList[i].classList.add("categories__block_links-active");
    });
  });
});
